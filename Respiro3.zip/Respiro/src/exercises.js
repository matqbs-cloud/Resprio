export const exercises = [
  {"title": "Box Breathing", "desc": "Prosta metoda relaksacyjna, używana m.in. przez oddziały Navy SEALs, aby błyskawicznie obniżyć poziom stresu, uspokoić nerwy i odzyskać koncentrację.", "pattern": [4,4,4,4]},
  {"title": "4-7-8", "desc": "Wdech 4s → zatrzymaj 7s → wydech 8s", "pattern": [4,7,8]},
  {"title": "Slow Calm", "desc": "Wdech 6s → pauza 3s → wydech 6s", "pattern": [6,3,6]},
  {"title": "Focus Breath", "desc": "Krótki rytm dla skupienia 3-3-3", "pattern": [3,3,3]},
  ];